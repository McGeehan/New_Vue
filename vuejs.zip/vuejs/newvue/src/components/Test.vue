<template>
  <div class="test">
  <input type="text" v-model="title"><br />
    <h1>{{title}}</h1>
    <p v-if="showName">{{user.firstName}}</p>
    <p v-else="showName">Nobody</p>
    <ul>
      <li v-for="item in items">{{item.title}}</li>
    </ul>
    <button v-on:click="greet('Hello World')">Say Greeting</button>
    <input type="text" v-on:keyup="pressKey">
  </div>
</template>

<script>
  export default {
    name: 'test',
    data() {
      return {
        title: 'Hello World',
        user: {
          firstName: 'John',
          lastName: 'Dope'
        },
        showName: true,
        items: [
        {title:'Item One'},
        {title: 'Item Two'},
        {title: 'Item Three'}
        ]
      }
    },
    methods: {
      greet: function(greeting){
        alert(greeting);
        },
    pressKey: function(){
      console.log('pressed');
      }
    }
  }
</script>

<style scoped>

</style>
